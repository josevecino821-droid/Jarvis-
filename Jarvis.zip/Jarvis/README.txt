JARVIS - proyecto Android nativo
1. Pon el modelo en app/src/main/assets/hand_landmarker.task
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
2. Abre la carpeta en Android Studio, espera al Gradle sync y pulsa Run.
Reacciones (tambien te sigue la cara y se pone feliz si sonries): saludar=feliz | pulgar arriba=feliz | paz=guino | puno=enfado | palma quieta=sorpresa |
corazon (2 manos o dedos)=corazones | agitar=enfado | 38C=calor | bateria<15%=triste | oscuro=sueno
Ademas, solo, pone caras aleatorias (guino, feliz, bizco, entrecerrar, ojos grandes).

NUEVO: al cargar el movil, ojos amarillos con rayos azules. Te escucha (espanol): hola, enfadate, te quiero,
duerme/despierta, triste, guina, sorpresa, calor, baila, mira a la izquierda/derecha/arriba/abajo, gracias.

ESTILO STARBOY: ojos unicos al azar (di "cambia los ojos"), caricias con vibracion (toca la pantalla),
se duerme y baja el brillo si lo ignoras 25 s, nervioso con ruido fuerte, tiembla de frio, se marea al agitar,
te reconoce al volver, efectos raros: arcoiris, glitch, matrix, galaxia (aparecen solos o di "fiesta", "matrix", "galaxia", "glitch").
