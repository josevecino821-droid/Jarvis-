JARVIS (copia de Starboy)
Como el Starboy original: NO entiende palabras, reacciona a lo que siente.
- Camara: te sigue con los ojos, te reconoce al volver, sonrisa=feliz, muy cerca=sorpresa, gestos de mano (3 fotogramas seguidos)
- Sonido: ruido fuerte = nervioso (solo mide volumen)
- Mover: agitar = mareo y luego enfado | Tocar = caricia con vibracion
- Bateria: cargando = rayos | caliente = sofocado | frio = tiembla | <15% = triste
- Ignorarlo 25 s = se duerme y baja el brillo
- Doble toque = ojos nuevos | mantener 1,5 s = cambiar entre estrella y pantalla completa
