package com.ojitos

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.*
import android.os.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.WindowManager
import kotlin.random.Random
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.text.Normalizer
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var eyes: EyesView
    private var landmarker: HandLandmarker? = null
    private val faceDet = FaceDetection.getClient(FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
        .setMinFaceSize(0.15f).build())
    private val exec = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var angryUntil = 0L
    @Volatile private var loveUntil = 0L
    @Volatile private var happyUntil = 0L
    @Volatile private var winkUntil = 0L
    @Volatile private var surprisedUntil = 0L
    @Volatile private var hot = false
    @Volatile private var sad = false
    @Volatile private var dark = false
    @Volatile private var charging = false
    @Volatile private var sadUntil = 0L
    @Volatile private var sleepUntil = 0L
    @Volatile private var hotUntil = 0L
    @Volatile private var dizzyUntil = 0L
    @Volatile private var nervousUntil = 0L
    @Volatile private var curiousUntil = 0L
    @Volatile private var coldUntil = 0L
    @Volatile private var petUntil = 0L
    @Volatile private var fxUntil = 0L
    @Volatile private var fxMood = Mood.RAINBOW
    @Volatile private var batCold = false
    @Volatile private var lastInteraction = SystemClock.uptimeMillis()
    private var lastFace = 0L
    private var sr: SpeechRecognizer? = null
    private var listeningOn = false
    private var shakes = 0; private var lastShake = 0L
    private val hist = ArrayDeque<Pair<Long, Float>>()
    private var palmSince = 0L

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.CAMERA] == true) startCamera()
        if (r[Manifest.permission.RECORD_AUDIO] == true) startListening()
    }
    private val tick = object : Runnable { override fun run() { refresh(); ui.postDelayed(this, 200) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        eyes = EyesView(this); setContentView(eyes)
        eyes.setEyes(getSharedPreferences("jarvis", MODE_PRIVATE).getLong("seed", 0L))
        eyes.setOnTouchListener { _, e ->            // caricias
            if (e.actionMasked != MotionEvent.ACTION_UP) { val n = SystemClock.uptimeMillis(); petUntil = n + 1200; lastInteraction = n }
            true
        }
        try {
            landmarker = HandLandmarker.createFromOptions(this, HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setNumHands(2).setRunningMode(RunningMode.IMAGE).build())
        } catch (e: Exception) { /* sin modelo: no hay gestos de manos, el resto funciona */ }
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME)
        pollBattery(); ui.post(tick)
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (Manifest.permission.CAMERA !in need) startCamera()
        if (need.isNotEmpty()) camPerm.launch(need.toTypedArray())
    }

    private fun pollBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        hot = temp >= 38f
        sad = !plugged && lvl * 100 / sc < 15
        charging = plugged; eyes.charge = lvl * 100 / sc
        batCold = temp in 1f..12f
        ui.postDelayed({ pollBattery() }, 5000)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        if (abs(g - 9.8f) > 13f) {
            val n = SystemClock.uptimeMillis()
            shakes = if (n - lastShake < 600) shakes + 1 else 1
            lastShake = n
            if (shakes >= 3) { dizzyUntil = n + 2500; angryUntil = n + 4500; lastInteraction = n }
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun refresh() {
        val n = SystemClock.uptimeMillis()
        eyes.mood = when {
            n < dizzyUntil -> Mood.DIZZY
            n < angryUntil -> Mood.ANGRY
            n < loveUntil -> Mood.LOVE
            n < happyUntil || n < petUntil -> Mood.HAPPY
            n < winkUntil -> Mood.WINK
            n < surprisedUntil -> Mood.SURPRISED
            n < sadUntil -> Mood.SAD
            n < fxUntil -> fxMood
            n < curiousUntil -> Mood.CURIOUS
            n < nervousUntil -> Mood.NERVOUS
            n < coldUntil || batCold -> Mood.COLD
            n < sleepUntil -> Mood.SLEEPY
            charging -> Mood.CHARGING
            hot || n < hotUntil -> Mood.HOT
            sad -> Mood.SAD
            dark -> Mood.SLEEPY
            n - lastInteraction > 25000 -> Mood.DOZING
            else -> Mood.IDLE
        }
        if (n < petUntil) eyes.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)   // ronroneo
        dim(if (eyes.mood == Mood.DOZING) .03f else -1f)
    }

    private fun dim(b: Float) {
        val lp = window.attributes
        if (lp.screenBrightness != b) { lp.screenBrightness = b; window.attributes = lp }
    }

    private fun reroll() {   // ojos nuevos y unicos
        val seed = Random.nextLong(1, Long.MAX_VALUE)
        getSharedPreferences("jarvis", MODE_PRIVATE).edit().putLong("seed", seed).apply()
        eyes.setEyes(seed); surprisedUntil = SystemClock.uptimeMillis() + 1200
    }

    // ---------- VOZ ----------
    private fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private fun handle(b: Bundle?) {
        val txt = norm(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.joinToString(" ") ?: return)
        val n = SystemClock.uptimeMillis()
        lastInteraction = n
        fun has(vararg w: String) = w.any { txt.contains(it) }
        fun look(x: Float, y: Float) { eyes.ovX = x; eyes.ovY = y; eyes.dance = false; eyes.overrideUntil = n + 3000 }
        when {
            has("despierta", "levanta") -> { sleepUntil = 0; surprisedUntil = n + 1500 }
            has("duerme", "buenas noches", "a dormir") -> sleepUntil = n + 12000
            has("enfad", "furios", "rabia") -> angryUntil = n + 4000
            has("te quiero", "te amo", "amor", "corazon", "guap") -> loveUntil = n + 4000
            has("triste", "llora", "pena", "feo", "tonto") -> sadUntil = n + 4000
            has("guina", "guino") -> winkUntil = n + 2500
            has("sorpresa", "wow", "madre mia") -> surprisedUntil = n + 2500
            has("calor") -> hotUntil = n + 5000
            has("baila") -> { eyes.dance = true; eyes.overrideUntil = n + 4000 }
            has("izquierda") -> look(-1f, 0f)
            has("derecha") -> look(1f, 0f)
            has("arriba") -> look(0f, -.6f)
            has("abajo") -> look(0f, .6f)
            has("frio") -> coldUntil = n + 5000
            has("fiesta", "arcoiris") -> { fxMood = Mood.RAINBOW; fxUntil = n + 4000 }
            has("matrix", "hacker") -> { fxMood = Mood.MATRIX; fxUntil = n + 4500 }
            has("galaxia", "estrellas") -> { fxMood = Mood.GALAXY; fxUntil = n + 4500 }
            has("glitch", "fallo") -> { fxMood = Mood.GLITCH; fxUntil = n + 3000 }
            has("cambia los ojos", "cambia de ojos", "ojos nuevos", "otros ojos") -> reroll()
            has("hola", "buenas", "hey", "que tal", "buenos dias", "gracias", "genial", "bien hecho") -> happyUntil = n + 3000
        }
    }

    private fun startListening() {
        if (sr != null || !SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this); sr = r; listeningOn = true
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(res: Bundle?) { handle(res); eyes.hearing = false; again(300) }
            override fun onPartialResults(p: Bundle?) { handle(p) }
            override fun onError(e: Int) {
                eyes.hearing = false
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) listeningOn = false
                else again(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 300)
            }
            override fun onBeginningOfSpeech() { eyes.hearing = true }
            override fun onEndOfSpeech() { eyes.hearing = false }
            override fun onRmsChanged(v: Float) { eyes.voice = ((v + 2f) / 12f).coerceIn(0f, 1f); if (v > 9.5f) nervousUntil = SystemClock.uptimeMillis() + 3000 }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        listen()
    }
    private fun listen() {
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        })
    }
    private fun again(ms: Long) { ui.postDelayed({ if (listeningOn) listen() }, ms) }
    private fun stopListening() { listeningOn = false; sr?.destroy(); sr = null }
    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening()
    }
    override fun onPause() { super.onPause(); stopListening() }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
            an.setAnalyzer(exec) { analyze(it) }
            val p = f.get(); p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, an)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun d(a: NormalizedLandmark, b: NormalizedLandmark) = hypot(a.x() - b.x(), a.y() - b.y())

    private fun analyze(img: ImageProxy) {
        try {
            val raw = img.toBitmap()
            val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()); postScale(-1f, 1f) }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            val s = Bitmap.createScaledBitmap(bmp, 8, 8, true)
            var sum = 0L
            for (i in 0 until 64) { val c = s.getPixel(i % 8, i / 8); sum += (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
            dark = sum / 64 < 30
            // cara: los ojos te siguen y si sonríes se ponen felices
            val face = try {
                Tasks.await(faceDet.process(InputImage.fromBitmap(bmp, 0))).maxByOrNull { it.boundingBox.width() }
            } catch (e: Exception) { null }
            if (face != null) {
                val nf = SystemClock.uptimeMillis(); lastInteraction = nf
                if (nf - lastFace > 8000) happyUntil = nf + 2500                 // te reconoce al volver
                lastFace = nf
                if (face.boundingBox.width() > bmp.width * .55f) surprisedUntil = nf + 1500   // muy cerca
                if ((face.smilingProbability ?: 0f) > .75f) happyUntil = nf + 1500
            }
            val hands = landmarker?.detect(BitmapImageBuilder(bmp).build())?.landmarks() ?: emptyList()
            val now = SystemClock.uptimeMillis()
            if (hands.isEmpty()) {
                if (face != null) {
                    eyes.lookX = ((face.boundingBox.centerX().toFloat() / bmp.width - .5f) * 3f).coerceIn(-1f, 1f)
                    eyes.lookY = ((face.boundingBox.centerY().toFloat() / bmp.height - .5f) * 3f).coerceIn(-.6f, .6f)
                } else eyes.lookX = null
                hist.clear(); palmSince = 0; return
            }
            val a = hands[0]
            lastInteraction = now
            eyes.lookX = (a[0].x() - .5f) * 2; eyes.lookY = a[0].y() - .5f
            val size = d(a[0], a[9])
            fun ext(tip: Int, pip: Int) = d(a[0], a[tip]) > d(a[0], a[pip]) * 1.1f
            val idx = ext(8, 6); val mid = ext(12, 10); val ring = ext(16, 14); val pnk = ext(20, 18)
            val thumbOut = d(a[4], a[17]) > d(a[3], a[17]) * 1.05f
            val open = idx && mid && ring && pnk
            val curled = !idx && !mid && !ring && !pnk
            hist.addLast(now to a[0].x())
            while (hist.first().first < now - 1000) hist.removeFirst()
            val xs = hist.map { it.second }; val range = xs.max() - xs.min()
            val still = open && range < .06f
            when {
                hands.size == 2 && d(a[4], hands[1][4]) < size * .8f && d(a[8], hands[1][8]) < size * .8f ->
                    loveUntil = now + 2500                                   // corazón con 2 manos
                curled && thumbOut && a[4].y() < a[3].y() && a[3].y() < a[2].y() ->
                    happyUntil = now + 2500                                  // pulgar arriba
                idx && mid && !ring && !pnk -> winkUntil = now + 2000        // paz = guiño
                d(a[4], a[8]) < size * .15f && !open -> loveUntil = now + 2500   // corazón con dedos
                idx && pnk && !mid && !ring -> { fxMood = Mood.RAINBOW; fxUntil = now + 3500 }   // rock
                idx && !mid && !ring && !pnk -> curiousUntil = now + 1800                         // dedo señalando
                curled -> angryUntil = now + 2000                            // puño = enfado
                open && range > .18f -> happyUntil = now + 2500              // saludar con la mano
                still -> { if (palmSince == 0L) palmSince = now
                    if (now - palmSince > 1200) surprisedUntil = now + 1500 }  // palma quieta = sorpresa
            }
            if (!still) palmSince = 0
        } catch (e: Exception) {
        } finally { img.close() }
    }
}
