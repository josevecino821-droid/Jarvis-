package com.ojitos

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.*
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var eyes: EyesView
    private var landmarker: HandLandmarker? = null
    private val faceDet = FaceDetection.getClient(FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
        .setMinFaceSize(0.15f).build())
    private val exec = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var angryUntil = 0L
    @Volatile private var dizzyUntil = 0L
    @Volatile private var loveUntil = 0L
    @Volatile private var happyUntil = 0L
    @Volatile private var winkUntil = 0L
    @Volatile private var surprisedUntil = 0L
    @Volatile private var nervousUntil = 0L
    @Volatile private var curiousUntil = 0L
    @Volatile private var petUntil = 0L
    @Volatile private var fxUntil = 0L
    @Volatile private var fxMood = Mood.RAINBOW
    @Volatile private var hot = false
    @Volatile private var sad = false
    @Volatile private var dark = false
    @Volatile private var charging = false
    @Volatile private var batCold = false
    @Volatile private var lastInteraction = SystemClock.uptimeMillis()
    private var lastFace = 0L
    private var shakes = 0; private var lastShake = 0L
    private val hist = ArrayDeque<Pair<Long, Float>>()
    private var palmSince = 0L; private var gLast = 0; private var gCount = 0
    @Volatile private var micOn = false

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.CAMERA] == true) startCamera()
        if (r[Manifest.permission.RECORD_AUDIO] == true) startMic()
    }
    private val tick = object : Runnable { override fun run() { refresh(); ui.postDelayed(this, 200) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        eyes = EyesView(this); setContentView(eyes)
        eyes.setEyes(getSharedPreferences("jarvis", MODE_PRIVATE).getLong("seed", 0L))
        // tocar = caricia | doble toque = ojos nuevos | mantener 1,5 s = estrella / pantalla completa
        var lastDown = 0L
        val hold = Runnable { eyes.star = !eyes.star }
        eyes.setOnTouchListener { _, e ->
            val n = SystemClock.uptimeMillis()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { if (n - lastDown < 300) reroll(); lastDown = n; ui.postDelayed(hold, 1500) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(hold)
            }
            if (e.actionMasked != MotionEvent.ACTION_UP) { petUntil = n + 1200; lastInteraction = n }
            true
        }
        try {
            landmarker = HandLandmarker.createFromOptions(this, HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setMinHandDetectionConfidence(.7f).setMinHandPresenceConfidence(.6f)
                .setNumHands(2).setRunningMode(RunningMode.IMAGE).build())
        } catch (e: Exception) { }
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME)
        pollBattery(); ui.post(tick)
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (Manifest.permission.CAMERA !in need) startCamera()
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
    }

    private fun pollBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        hot = temp >= 38f
        batCold = temp in 1f..12f
        sad = !plugged && lvl * 100 / sc < 15
        charging = plugged; eyes.charge = lvl * 100 / sc
        ui.postDelayed({ pollBattery() }, 5000)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        if (abs(g - 9.8f) > 16f) {
            val n = SystemClock.uptimeMillis()
            shakes = if (n - lastShake < 600) shakes + 1 else 1
            lastShake = n
            if (shakes >= 4) { dizzyUntil = n + 2500; angryUntil = n + 4500; lastInteraction = n; shakes = 0 }
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun refresh() {
        val n = SystemClock.uptimeMillis()
        eyes.mood = when {
            n < dizzyUntil -> Mood.DIZZY
            n < angryUntil -> Mood.ANGRY
            n < loveUntil -> Mood.LOVE
            n < happyUntil || n < petUntil -> Mood.HAPPY
            n < winkUntil -> Mood.WINK
            n < surprisedUntil -> Mood.SURPRISED
            n < fxUntil -> fxMood
            n < curiousUntil -> Mood.CURIOUS
            n < nervousUntil -> Mood.NERVOUS
            batCold -> Mood.COLD
            charging -> Mood.CHARGING
            hot -> Mood.HOT
            sad -> Mood.SAD
            dark -> Mood.SLEEPY
            n - lastInteraction > 25000 -> Mood.DOZING
            else -> Mood.IDLE
        }
        if (n < petUntil) eyes.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)   // ronroneo
        dim(if (eyes.mood == Mood.DOZING) .03f else -1f)
    }

    private fun dim(b: Float) {
        val lp = window.attributes
        if (lp.screenBrightness != b) { lp.screenBrightness = b; window.attributes = lp }
    }

    private fun reroll() {
        val seed = (1L..Long.MAX_VALUE).random()
        getSharedPreferences("jarvis", MODE_PRIVATE).edit().putLong("seed", seed).apply()
        eyes.setEyes(seed); surprisedUntil = SystemClock.uptimeMillis() + 1200
    }

    // ---------- SONIDO: solo mide el ruido, como el Starboy (no entiende palabras) ----------
    private fun startMic() {
        if (micOn) return
        try {
            val sz = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (sz <= 0) return
            val r = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, sz * 2)
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return }
            micOn = true; r.startRecording()
            Thread {
                val buf = ShortArray(1024); var loud = 0
                try {
                    while (micOn) {
                        val n = r.read(buf, 0, buf.size); if (n <= 0) continue
                        var sum = 0.0; for (i in 0 until n) sum += buf[i] * buf[i].toDouble()
                        val rms = sqrt(sum / n)
                        eyes.voice = (rms / 6000.0).coerceIn(0.0, 1.0).toFloat()
                        eyes.hearing = rms > 2000
                        if (rms > 2500) lastInteraction = SystemClock.uptimeMillis()
                        if (rms > 10000) { loud++; if (loud >= 2) nervousUntil = SystemClock.uptimeMillis() + 3000 } else loud = 0
                    }
                } finally { try { r.stop(); r.release() } catch (e: Exception) { } }
            }.start()
        } catch (e: Exception) { micOn = false }
    }
    private fun stopMic() { micOn = false; eyes.hearing = false }
    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startMic()
    }
    override fun onPause() { super.onPause(); stopMic() }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
            an.setAnalyzer(exec) { analyze(it) }
            val p = f.get(); p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, an)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun d(a: NormalizedLandmark, b: NormalizedLandmark) = hypot(a.x() - b.x(), a.y() - b.y())

    private fun analyze(img: ImageProxy) {
        try {
            val raw = img.toBitmap()
            val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()); postScale(-1f, 1f) }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            val s = Bitmap.createScaledBitmap(bmp, 8, 8, true)
            var sum = 0L
            for (i in 0 until 64) { val c = s.getPixel(i % 8, i / 8); sum += (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
            dark = sum / 64 < 30
            val face = try {
                Tasks.await(faceDet.process(InputImage.fromBitmap(bmp, 0))).maxByOrNull { it.boundingBox.width() }
            } catch (e: Exception) { null }
            val now = SystemClock.uptimeMillis()
            if (face != null) {
                lastInteraction = now
                if (now - lastFace > 8000) happyUntil = now + 2500                      // te reconoce al volver
                lastFace = now
                if (face.boundingBox.width() > bmp.width * .55f) surprisedUntil = now + 1500   // muy cerca
                if ((face.smilingProbability ?: 0f) > .8f) happyUntil = now + 1500
            }
            val hands = landmarker?.detect(BitmapImageBuilder(bmp).build())?.landmarks() ?: emptyList()
            if (hands.isEmpty()) {
                gLast = 0; gCount = 0; palmSince = 0; hist.clear()
                if (face != null) {
                    eyes.lookX = ((face.boundingBox.centerX().toFloat() / bmp.width - .5f) * 3f).coerceIn(-1f, 1f)
                    eyes.lookY = ((face.boundingBox.centerY().toFloat() / bmp.height - .5f) * 3f).coerceIn(-.6f, .6f)
                } else eyes.lookX = null
                return
            }
            val a = hands[0]
            lastInteraction = now
            eyes.lookX = (a[0].x() - .5f) * 2; eyes.lookY = a[0].y() - .5f
            val size = d(a[0], a[9])
            fun ext(tip: Int, pip: Int) = d(a[0], a[tip]) > d(a[0], a[pip]) * 1.1f
            val idx = ext(8, 6); val mid = ext(12, 10); val ring = ext(16, 14); val pnk = ext(20, 18)
            val thumbOut = d(a[4], a[17]) > d(a[3], a[17]) * 1.05f
            val open = idx && mid && ring && pnk
            val curled = !idx && !mid && !ring && !pnk
            hist.addLast(now to a[0].x())
            while (hist.first().first < now - 1000) hist.removeFirst()
            val xs = hist.map { it.second }; val range = xs.max() - xs.min()
            val still = open && range < .06f
            if (still) { if (palmSince == 0L) palmSince = now } else palmSince = 0
            // cada gesto tiene que mantenerse unos fotogramas para valer (evita falsas alarmas)
            val g = when {
                hands.size == 2 && d(a[4], hands[1][4]) < size * .8f && d(a[8], hands[1][8]) < size * .8f -> 1
                curled && thumbOut && a[4].y() < a[3].y() && a[3].y() < a[2].y() -> 2
                idx && mid && !ring && !pnk -> 3
                d(a[4], a[8]) < size * .15f && !open -> 1
                idx && pnk && !mid && !ring -> 4
                idx && !mid && !ring && !pnk -> 5
                curled -> 6
                open && range > .18f -> 7
                still && now - palmSince > 1200 -> 8
                else -> 0
            }
            if (g == gLast) gCount++ else { gLast = g; gCount = 1 }
            if (g != 0 && gCount >= (if (g == 6) 8 else 3)) when (g) {
                1 -> loveUntil = now + 2500
                2, 7 -> happyUntil = now + 2500
                3 -> winkUntil = now + 2000
                4 -> { fxMood = Mood.RAINBOW; fxUntil = now + 3500 }
                5 -> curiousUntil = now + 1800
                6 -> angryUntil = now + 2000
                8 -> surprisedUntil = now + 1500
            }
        } catch (e: Exception) {
        } finally { img.close() }
    }
}
