package com.ojitos

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.*
import kotlin.random.Random

enum class Mood { IDLE, ANGRY, HOT, LOVE, SLEEPY, HAPPY, SURPRISED, SAD, WINK, SQUINT, BIG, CROSS, CHARGING,
    DIZZY, NERVOUS, COLD, DOZING, RAINBOW, GLITCH, MATRIX, GALAXY, CURIOUS }

class EyesView(c: Context) : View(c) {
    @Volatile var mood = Mood.IDLE
    @Volatile var lookX: Float? = null
    @Volatile var lookY = 0f
    @Volatile var charge = 50            // % de bateria
    @Volatile var voice = 0f             // volumen de tu voz 0..1
    @Volatile var hearing = false        // te esta escuchando hablar
    @Volatile var overrideUntil = 0L; @Volatile var ovX = 0f; @Volatile var ovY = 0f; @Volatile var dance = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val black = Paint().apply { color = Color.BLACK }
    private val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(85, 110, 25, 0) }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(90, 95, 230, 255); strokeCap = Paint.Cap.ROUND }
    private val crack = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFA8F4FF.toInt(); strokeCap = Paint.Cap.ROUND }
    private val rect = RectF(); private val path = Path(); private val path2 = Path()
    private var baseColor = 0xFFFF7A1A.toInt(); private var pattern = 0; private var pupilShape = 0; private var tier = 0
    private val dotp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(85, 110, 25, 0) }
    private val spiral = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeCap = Paint.Cap.ROUND }
    private val rare = listOf(Mood.RAINBOW, Mood.GLITCH, Mood.MATRIX, Mood.GALAXY)
    private val plain = setOf(Mood.IDLE, Mood.WINK, Mood.SQUINT, Mood.BIG, Mood.CROSS, Mood.CURIOUS)
    private val rainbow = intArrayOf(0xFFFF3B30.toInt(), 0xFFFFCC00.toInt(), 0xFF34C759.toInt(), 0xFF00C7FF.toInt(), 0xFF7A5CFF.toInt(), 0xFFFF3B30.toInt())

    /** Ojos unicos: color, dibujo, pupila y rareza salen de un numero al azar (0 = los naranjas de siempre) */
    fun setEyes(seed: Long) {
        val z = abs(seed)
        if (seed == 0L) { baseColor = 0xFFFF7A1A.toInt(); pattern = 0; pupilShape = 0; tier = 0; return }
        baseColor = Color.HSVToColor(floatArrayOf((z % 360).toFloat(), .9f, 1f))
        pattern = ((z / 360) % 4).toInt(); pupilShape = ((z / 1440) % 3).toInt()
        val r = (z / 4320) % 100
        tier = when { r >= 99 -> 3; r >= 94 -> 2; r >= 70 -> 1; else -> 0 }
    }
    private var lx = 0f; private var ly = 0f; private var tx = 0f; private var ty = 0f
    private var hAmt = 1f; private var blink = 0f; private var nextBlink = 0L; private var wander = 0L
    private var quirk = Mood.IDLE; private var quirkUntil = 0L; private var nextQuirk = 0L
    private val quirks = listOf(Mood.HAPPY, Mood.WINK, Mood.SQUINT, Mood.BIG, Mood.CROSS, Mood.CURIOUS)
    private var curColor = 0xFFFF7A1A.toInt(); private var lastM = Mood.IDLE; private var pop = 0f; private var vs = 0f

    private fun color(m: Mood) = when (m) {
        Mood.ANGRY -> 0xFFFF2A2A.toInt(); Mood.HOT -> 0xFFFF4A1A.toInt(); Mood.LOVE -> 0xFFFF4F9A.toInt()
        Mood.SLEEPY -> 0xFF8A7CFF.toInt(); Mood.HAPPY -> 0xFFFFC23A.toInt(); Mood.SURPRISED -> 0xFFFFA040.toInt()
        Mood.SAD -> 0xFF4D9BFF.toInt(); Mood.CHARGING -> 0xFFFFA81A.toInt(); Mood.COLD -> 0xFF7FC8FF.toInt(); Mood.NERVOUS -> 0xFFFFD08A.toInt(); else -> baseColor
    }
    private fun mix(a: Int, b: Int, f: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt())

    private fun heart(cv: Canvas, x: Float, y: Float, s: Float) {
        path.reset(); path.moveTo(x, y + s * .9f)
        path.cubicTo(x - s * 1.5f, y - s * .1f, x - s * .9f, y - s * 1.1f, x, y - s * .4f)
        path.cubicTo(x + s * .9f, y - s * 1.1f, x + s * 1.5f, y - s * .1f, x, y + s * .9f)
        cv.drawPath(path, p)
    }

    private fun lid(cv: Canvas, x: Float, y: Float, R: Float, inn: Int) {
        path.reset()
        path.moveTo(x - inn * R * 1.2f, y - R * 1.7f); path.lineTo(x + inn * R * 1.2f, y - R * 1.7f)
        path.lineTo(x + inn * R * 1.2f, y - R * .1f); path.lineTo(x - inn * R * 1.2f, y - R * 1.0f)
        path.close(); cv.drawPath(path, black)
    }

    override fun onDraw(cv: Canvas) {
        val now = SystemClock.uptimeMillis(); val t = now / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        if (now > nextQuirk) {
            quirk = if (Random.nextInt(6) == 0) rare.random() else quirks.random(); quirkUntil = now + 1500 + Random.nextLong(1500)
            nextQuirk = now + 5000 + Random.nextLong(7000)
        }
        val m = if (mood == Mood.IDLE && now < quirkUntil) quirk else mood
        if (m != lastM) { pop = 1f; lastM = m }            // "boing" al cambiar de emocion
        pop *= .9f
        vs += ((if (hearing) voice else 0f) - vs) * .25f   // pupilas se dilatan con tu voz
        curColor = mix(curColor, color(m), .15f)           // color con transicion suave
        cv.drawColor(Color.BLACK)
        // mirada
        val ov = now < overrideUntil
        val lk: Float? = if (ov) (if (dance) sin(t * 4f) else ovX) else lookX
        if (lk != null) { tx = lk; ty = if (ov) (if (dance) sin(t * 3f) * .3f else ovY) else lookY }
        else if (now > wander) { tx = Random.nextFloat() * 2 - 1; ty = Random.nextFloat() - .5f; wander = now + 1200 + Random.nextLong(2500) }
        lx += (tx - lx) * .12f; ly += (ty - ly) * .12f
        val gx = lx + sin(t * 1.7f) * .04f; val gy = ly + sin(t * 2.1f) * .03f   // micromovimientos
        if (now > nextBlink) { blink = 1f; nextBlink = now + (if (Random.nextInt(5) == 0) 220L else 1800L + Random.nextLong(3500)) }
        if (blink > 0) blink = max(0f, blink - .09f)
        val bl = 1f - sin(blink * PI.toFloat()) * .95f
        val target = when (m) { Mood.ANGRY -> .8f; Mood.HOT -> .45f; Mood.SLEEPY -> .06f; Mood.SQUINT -> .35f; Mood.SAD -> .75f; Mood.COLD -> .8f; Mood.DOZING -> .3f + .2f * sin(t * .7f); else -> 1f }
        hAmt += (target - hAmt) * .15f
        val k = 1f + pop * .12f
        val R = min(w, h) * .22f * (1f + sin(t * 1.8f) * .012f) * (if (hearing) 1.06f else 1f)
        val cy = h * .46f
        hp.strokeWidth = R * .035f; glow.strokeWidth = R * .11f; crack.strokeWidth = R * .045f; spiral.strokeWidth = R * .07f
        for (side in intArrayOf(-1, 1)) {
            var x = w / 2 + side * R * .95f + gx * R * .15f; val y = cy + gy * R * .15f
            if (m == Mood.HOT) x += sin(t * 14) * R * .04f
            if (m == Mood.ANGRY) x += sin(t * 40) * R * .05f
            if (m == Mood.COLD) x += sin(t * 45) * R * .04f
            if (m == Mood.NERVOUS) x += sin(t * 30 + side) * R * .03f
            if (m == Mood.DIZZY) x += sin(t * 6 + side) * R * .12f
            if (m == Mood.CROSS) x = w / 2 + side * R * .5f
            p.color = curColor
            if (m == Mood.LOVE) { heart(cv, w / 2 + side * R * 1.3f, y, R * .7f * k * (1 + sin(t * 8) * .1f)); continue }
            if (m == Mood.HAPPY || (m == Mood.WINK && side == 1)) {
                p.style = Paint.Style.STROKE; p.strokeWidth = R * .26f; p.strokeCap = Paint.Cap.ROUND
                rect.set(x - R * .7f, y - R * .5f, x + R * .7f, y + R * .9f)
                cv.drawArc(rect, 200f, 140f, false, p); p.style = Paint.Style.FILL; continue
            }
            val big = m == Mood.BIG || m == Mood.SURPRISED
            val ew = R * .8f * k * (if (m == Mood.BIG) 1.2f else 1f)
            val eh = max(R * 1.05f * k * (if (m == Mood.CURIOUS && side == 1) .6f else 1f) * (if (m == Mood.SURPRISED) 1.3f else 1f) * hAmt *
                (if (m == Mood.SLEEPY || big) 1f else bl) * (if (m == Mood.BIG) 1.2f else 1f), 3f)
            rect.set(x - ew, y - eh, x + ew, y + eh)
            path.reset(); path.addOval(rect, Path.Direction.CW)
            cv.save(); cv.rotate(side * 10f + (if (m == Mood.CURIOUS) 14f else 0f), x, y)
            val lite = Color.rgb(min(255, Color.red(baseColor) + 90), min(255, Color.green(baseColor) + 90), min(255, Color.blue(baseColor) + 90))
            if (m == Mood.GLITCH) {                                     // separacion de color
                val gl = Random((t * 12).toInt() * 7 + side + 3); val d = R * (.03f + gl.nextFloat() * .08f)
                p.color = 0xFFFF0050.toInt(); cv.save(); cv.translate(-d, 0f); cv.drawOval(rect, p); cv.restore()
                p.color = 0xFF00E5FF.toInt(); cv.save(); cv.translate(d, 0f); cv.drawOval(rect, p); cv.restore()
                p.color = curColor
            }
            p.shader = when {
                m == Mood.CHARGING -> RadialGradient(x, y + R * .1f, ew * 1.3f, 0xFFFFE066.toInt(), 0xFFFF8A00.toInt(), Shader.TileMode.CLAMP)
                m == Mood.GALAXY -> RadialGradient(x, y, ew * 1.2f, 0xFF3A2A9A.toInt(), 0xFF05001A.toInt(), Shader.TileMode.CLAMP)
                m == Mood.RAINBOW || (tier == 3 && m in plain) -> SweepGradient(x, y, rainbow, null).also {
                    it.setLocalMatrix(Matrix().apply { setRotate(t * (if (m == Mood.RAINBOW) 150f else 40f), x, y) }) }
                tier >= 1 && m in plain -> RadialGradient(x, y + R * .1f, ew * 1.3f, lite, baseColor, Shader.TileMode.CLAMP)
                else -> null
            }
            if (m == Mood.MATRIX) p.color = 0xFF001A08.toInt()
            cv.drawOval(rect, p); p.shader = null; p.color = curColor
            cv.save(); cv.clipPath(path)
            when (m) {
                Mood.CHARGING -> {                                      // rayos electricos
                    val rnd = Random((t * 7).toInt() * 31 + side)
                    val n = 4 + charge / 25
                    val oy = y + R * .1f
                    for (i in 0 until n) {
                        var a = i * 6.2832f / n + rnd.nextFloat() * .6f
                        var px = x; var py = oy
                        path2.reset(); path2.moveTo(px, py)
                        for (q in 0..3) { a += (rnd.nextFloat() - .5f) * 1.2f; px += cos(a) * R * .3f; py += sin(a) * R * .38f; path2.lineTo(px, py) }
                        cv.drawPath(path2, glow); cv.drawPath(path2, crack)
                    }
                    p.color = 0xFFD8FBFF.toInt()
                    cv.drawCircle(x, oy, R * .14f * (1f + .3f * sin(t * 12f)), p)
                }
                Mood.GALAXY -> {
                    p.color = Color.WHITE
                    for (i in 0..40) {
                        val a = i * .5f + t * 1.4f; val r = i * R * .028f
                        cv.drawCircle(x + cos(a) * r * .9f, y + sin(a) * r * 1.1f, R * (.015f + (i % 5) * .008f), p)
                    }
                }
                Mood.MATRIX -> {
                    p.textSize = R * .24f; p.color = 0xFF2BFF63.toInt()
                    val mr = Random((t * 8).toInt() + side)
                    for (c in -2..2) {
                        val fall = (t * R * 1.6f + c * 37f) % (eh * 2.6f)
                        for (r in 0..6) {
                            p.alpha = (255 * (1f - r / 7f)).toInt()
                            cv.drawText(if (mr.nextBoolean()) "1" else "0", x + c * R * .3f - R * .07f, y - eh + fall - r * R * .28f, p)
                        }
                    }
                    p.alpha = 255
                }
                else -> {
                    val st = R * .16f
                    if (m != Mood.RAINBOW && pattern != 3) for (i in -9..9) {       // dibujo del iris
                        val o = i * st
                        if (pattern == 1) { for (j in -9..9) cv.drawCircle(x + o, y + j * st + (i and 1) * st / 2, R * .025f, dotp) }
                        else {
                            cv.drawLine(x - ew * 1.2f + o, y - eh * 1.2f, x + ew * 1.2f + o, y + eh * 1.2f, hp)
                            if (pattern == 0) cv.drawLine(x + ew * 1.2f + o, y - eh * 1.2f, x - ew * 1.2f + o, y + eh * 1.2f, hp)
                        }
                    }
                    if (m == Mood.GLITCH) {
                        val gl = Random((t * 12).toInt() * 7 + side)
                        for (i in 0..2) { val by = y - eh + gl.nextFloat() * 2 * eh; cv.drawRect(x - ew, by, x + ew, by + R * .07f, black) }
                    }
                    p.color = Color.WHITE
                    var pr = R * .46f * (if (m == Mood.SURPRISED) 1.15f else 1f) * (1f + .3f * vs)
                    var pxx = x - side * R * .22f + gx * R * .12f; var pyy = y + R * .1f + gy * R * .12f
                    if (m == Mood.NERVOUS) { pr *= .5f; pxx += sin(t * 35f) * R * .06f; pyy += cos(t * 29f) * R * .04f }
                    if (m == Mood.DIZZY) {
                        path2.reset()
                        for (i in 0..50) {
                            val a = i * .4f + t * 9f; val r = i * R * .016f
                            val qx = x + cos(a) * r; val qy = y + sin(a) * r * 1.1f
                            if (i == 0) path2.moveTo(qx, qy) else path2.lineTo(qx, qy)
                        }
                        cv.drawPath(path2, spiral)
                    } else {
                        val sx = if (pupilShape == 1) .75f else if (pupilShape == 2) 1.25f else 1f
                        val sy = if (pupilShape == 1) 1.25f else if (pupilShape == 2) .8f else 1f
                        rect.set(pxx - pr * sx, pyy - pr * sy, pxx + pr * sx, pyy + pr * sy); cv.drawOval(rect, p)
                    }
                    if (tier == 2 && m in plain) {                      // ojos epicos: destellos
                        p.color = Color.WHITE
                        for (i in 0..5) {
                            p.alpha = (abs(sin(t * 2f + i * 1.7f)) * 255).toInt()
                            cv.drawCircle(x + cos(i * 2.1f) * ew * .6f, y + sin(i * 1.3f + 1f) * eh * .6f, R * .04f, p)
                        }
                        p.alpha = 255
                    }
                }
            }
            cv.restore()
            p.color = curColor
            if (m == Mood.ANGRY) lid(cv, x, y, R, -side)
            if (m == Mood.SAD) lid(cv, x, y, R, side)
            cv.restore()
            when (m) {
                Mood.SAD -> {
                    val f = (t * .6f + (if (side > 0) .3f else 0f)) % 1f
                    p.color = 0xFF99DDFF.toInt(); p.alpha = ((1 - f) * 255).toInt()
                    cv.drawCircle(x + side * R * .6f, y + R * .9f + f * R * 1.3f, R * .1f, p)
                    p.alpha = 255; p.color = curColor
                }
                Mood.HOT -> {
                    p.color = 0xFF66FFFF.toInt()
                    for (i in 0..2) {
                        val f = (t * .8f + i / 3f + (if (side > 0) .17f else 0f)) % 1f
                        p.alpha = ((1 - f) * 255).toInt()
                        val cx = x + (i - 1) * R * .5f; val cyy = y - R * .7f + f * R * 2.2f
                        rect.set(cx - R * .07f, cyy - R * .12f, cx + R * .07f, cyy + R * .12f); cv.drawOval(rect, p)
                    }
                    p.alpha = 255; p.color = curColor
                }
                Mood.SLEEPY, Mood.DOZING -> { p.textSize = R * .4f; cv.drawText("z", x + side * R * .3f, y - R * .6f - (t * 30) % 40, p) }
                else -> {}
            }
        }
        postInvalidateOnAnimation()
    }
}
