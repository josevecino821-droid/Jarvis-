package com.ojitos

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.*
import kotlin.random.Random

enum class Mood { IDLE, ANGRY, HOT, LOVE, SLEEPY, HAPPY, SURPRISED, SAD, WINK, SQUINT, BIG, CROSS, CHARGING }

class EyesView(c: Context) : View(c) {
    @Volatile var mood = Mood.IDLE
    @Volatile var lookX: Float? = null
    @Volatile var lookY = 0f
    @Volatile var charge = 50            // % de bateria
    @Volatile var voice = 0f             // volumen de tu voz 0..1
    @Volatile var hearing = false        // te esta escuchando hablar
    @Volatile var overrideUntil = 0L; @Volatile var ovX = 0f; @Volatile var ovY = 0f; @Volatile var dance = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val black = Paint().apply { color = Color.BLACK }
    private val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(85, 110, 25, 0) }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(90, 95, 230, 255); strokeCap = Paint.Cap.ROUND }
    private val crack = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFA8F4FF.toInt(); strokeCap = Paint.Cap.ROUND }
    private val rect = RectF(); private val path = Path(); private val path2 = Path()
    private var lx = 0f; private var ly = 0f; private var tx = 0f; private var ty = 0f
    private var hAmt = 1f; private var blink = 0f; private var nextBlink = 0L; private var wander = 0L
    private var quirk = Mood.IDLE; private var quirkUntil = 0L; private var nextQuirk = 0L
    private val quirks = listOf(Mood.HAPPY, Mood.WINK, Mood.SQUINT, Mood.BIG, Mood.CROSS)
    private var curColor = 0xFFFF7A1A.toInt(); private var lastM = Mood.IDLE; private var pop = 0f; private var vs = 0f

    private fun color(m: Mood) = when (m) {
        Mood.ANGRY -> 0xFFFF2A2A.toInt(); Mood.HOT -> 0xFFFF4A1A.toInt(); Mood.LOVE -> 0xFFFF4F9A.toInt()
        Mood.SLEEPY -> 0xFF8A7CFF.toInt(); Mood.HAPPY -> 0xFFFFC23A.toInt(); Mood.SURPRISED -> 0xFFFFA040.toInt()
        Mood.SAD -> 0xFF4D9BFF.toInt(); Mood.CHARGING -> 0xFFFFA81A.toInt(); else -> 0xFFFF7A1A.toInt()
    }
    private fun mix(a: Int, b: Int, f: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt())

    private fun heart(cv: Canvas, x: Float, y: Float, s: Float) {
        path.reset(); path.moveTo(x, y + s * .9f)
        path.cubicTo(x - s * 1.5f, y - s * .1f, x - s * .9f, y - s * 1.1f, x, y - s * .4f)
        path.cubicTo(x + s * .9f, y - s * 1.1f, x + s * 1.5f, y - s * .1f, x, y + s * .9f)
        cv.drawPath(path, p)
    }

    private fun lid(cv: Canvas, x: Float, y: Float, R: Float, inn: Int) {
        path.reset()
        path.moveTo(x - inn * R * 1.2f, y - R * 1.7f); path.lineTo(x + inn * R * 1.2f, y - R * 1.7f)
        path.lineTo(x + inn * R * 1.2f, y - R * .1f); path.lineTo(x - inn * R * 1.2f, y - R * 1.0f)
        path.close(); cv.drawPath(path, black)
    }

    override fun onDraw(cv: Canvas) {
        val now = SystemClock.uptimeMillis(); val t = now / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        if (now > nextQuirk) {
            quirk = quirks.random(); quirkUntil = now + 1500 + Random.nextLong(1500)
            nextQuirk = now + 5000 + Random.nextLong(7000)
        }
        val m = if (mood == Mood.IDLE && now < quirkUntil) quirk else mood
        if (m != lastM) { pop = 1f; lastM = m }            // "boing" al cambiar de emocion
        pop *= .9f
        vs += ((if (hearing) voice else 0f) - vs) * .25f   // pupilas se dilatan con tu voz
        curColor = mix(curColor, color(m), .15f)           // color con transicion suave
        cv.drawColor(Color.BLACK)
        // mirada
        val ov = now < overrideUntil
        val lk: Float? = if (ov) (if (dance) sin(t * 4f) else ovX) else lookX
        if (lk != null) { tx = lk; ty = if (ov) (if (dance) sin(t * 3f) * .3f else ovY) else lookY }
        else if (now > wander) { tx = Random.nextFloat() * 2 - 1; ty = Random.nextFloat() - .5f; wander = now + 1200 + Random.nextLong(2500) }
        lx += (tx - lx) * .12f; ly += (ty - ly) * .12f
        val gx = lx + sin(t * 1.7f) * .04f; val gy = ly + sin(t * 2.1f) * .03f   // micromovimientos
        if (now > nextBlink) { blink = 1f; nextBlink = now + (if (Random.nextInt(5) == 0) 220L else 1800L + Random.nextLong(3500)) }
        if (blink > 0) blink = max(0f, blink - .09f)
        val bl = 1f - sin(blink * PI.toFloat()) * .95f
        val target = when (m) { Mood.ANGRY -> .8f; Mood.HOT -> .45f; Mood.SLEEPY -> .06f; Mood.SQUINT -> .35f; Mood.SAD -> .75f; else -> 1f }
        hAmt += (target - hAmt) * .15f
        val k = 1f + pop * .12f
        val R = min(w, h) * .22f * (1f + sin(t * 1.8f) * .012f) * (if (hearing) 1.06f else 1f)
        val cy = h * .46f
        hp.strokeWidth = R * .035f; glow.strokeWidth = R * .11f; crack.strokeWidth = R * .045f
        for (side in intArrayOf(-1, 1)) {
            var x = w / 2 + side * R * .95f + gx * R * .15f; val y = cy + gy * R * .15f
            if (m == Mood.HOT) x += sin(t * 14) * R * .04f
            if (m == Mood.ANGRY) x += sin(t * 40) * R * .05f
            if (m == Mood.CROSS) x = w / 2 + side * R * .5f
            p.color = curColor
            if (m == Mood.LOVE) { heart(cv, w / 2 + side * R * 1.3f, y, R * .7f * k * (1 + sin(t * 8) * .1f)); continue }
            if (m == Mood.HAPPY || (m == Mood.WINK && side == 1)) {
                p.style = Paint.Style.STROKE; p.strokeWidth = R * .26f; p.strokeCap = Paint.Cap.ROUND
                rect.set(x - R * .7f, y - R * .5f, x + R * .7f, y + R * .9f)
                cv.drawArc(rect, 200f, 140f, false, p); p.style = Paint.Style.FILL; continue
            }
            val big = m == Mood.BIG || m == Mood.SURPRISED
            val ew = R * .8f * k * (if (m == Mood.BIG) 1.2f else 1f)
            val eh = max(R * 1.05f * k * (if (m == Mood.SURPRISED) 1.3f else 1f) * hAmt *
                (if (m == Mood.SLEEPY || big) 1f else bl) * (if (m == Mood.BIG) 1.2f else 1f), 3f)
            rect.set(x - ew, y - eh, x + ew, y + eh)
            path.reset(); path.addOval(rect, Path.Direction.CW)
            cv.save(); cv.rotate(side * 10f, x, y)
            if (m == Mood.CHARGING)
                p.shader = RadialGradient(x, y + R * .1f, ew * 1.3f, 0xFFFFE066.toInt(), 0xFFFF8A00.toInt(), Shader.TileMode.CLAMP)
            cv.drawOval(rect, p); p.shader = null
            cv.save(); cv.clipPath(path)
            if (m == Mood.CHARGING) {                                   // rayos electricos
                val rnd = Random((t * 7).toInt() * 31 + side)
                val n = 4 + charge / 25
                val ox = x; val oy = y + R * .1f
                for (i in 0 until n) {
                    var a = i * 6.2832f / n + rnd.nextFloat() * .6f
                    var px = ox; var py = oy
                    path2.reset(); path2.moveTo(px, py)
                    for (s in 0..3) { a += (rnd.nextFloat() - .5f) * 1.2f; px += cos(a) * R * .3f; py += sin(a) * R * .38f; path2.lineTo(px, py) }
                    cv.drawPath(path2, glow); cv.drawPath(path2, crack)
                }
                p.color = 0xFFD8FBFF.toInt()
                cv.drawCircle(ox, oy, R * .14f * (1f + .3f * sin(t * 12f)), p)
            } else {
                val st = R * .16f
                for (i in -9..9) {                                      // rejilla
                    val o = i * st
                    cv.drawLine(x - ew * 1.2f + o, y - eh * 1.2f, x + ew * 1.2f + o, y + eh * 1.2f, hp)
                    cv.drawLine(x + ew * 1.2f + o, y - eh * 1.2f, x - ew * 1.2f + o, y + eh * 1.2f, hp)
                }
                p.color = Color.WHITE                                   // pupila
                val pr = R * .46f * (if (m == Mood.SURPRISED) 1.15f else 1f) * (1f + .3f * vs)
                cv.drawCircle(x - side * R * .22f + gx * R * .12f, y + R * .1f + gy * R * .12f, pr, p)
            }
            cv.restore()
            p.color = curColor
            if (m == Mood.ANGRY) lid(cv, x, y, R, -side)
            if (m == Mood.SAD) lid(cv, x, y, R, side)
            cv.restore()
            when (m) {
                Mood.SAD -> {
                    val f = (t * .6f + (if (side > 0) .3f else 0f)) % 1f
                    p.color = 0xFF99DDFF.toInt(); p.alpha = ((1 - f) * 255).toInt()
                    cv.drawCircle(x + side * R * .6f, y + R * .9f + f * R * 1.3f, R * .1f, p)
                    p.alpha = 255; p.color = curColor
                }
                Mood.HOT -> {
                    p.color = 0xFF66FFFF.toInt()
                    for (i in 0..2) {
                        val f = (t * .8f + i / 3f + (if (side > 0) .17f else 0f)) % 1f
                        p.alpha = ((1 - f) * 255).toInt()
                        val cx = x + (i - 1) * R * .5f; val cyy = y - R * .7f + f * R * 2.2f
                        rect.set(cx - R * .07f, cyy - R * .12f, cx + R * .07f, cyy + R * .12f); cv.drawOval(rect, p)
                    }
                    p.alpha = 255; p.color = curColor
                }
                Mood.SLEEPY -> { p.textSize = R * .4f; cv.drawText("z", x + side * R * .3f, y - R * .6f - (t * 30) % 40, p) }
                else -> {}
            }
        }
        postInvalidateOnAnimation()
    }
}
