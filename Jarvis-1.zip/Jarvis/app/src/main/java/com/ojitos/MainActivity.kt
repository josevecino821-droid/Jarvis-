package com.ojitos

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.*
import android.os.*
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var eyes: EyesView
    private var landmarker: HandLandmarker? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var angryUntil = 0L
    @Volatile private var loveUntil = 0L
    @Volatile private var happyUntil = 0L
    @Volatile private var winkUntil = 0L
    @Volatile private var surprisedUntil = 0L
    @Volatile private var hot = false
    @Volatile private var sad = false
    @Volatile private var dark = false
    private var shakes = 0; private var lastShake = 0L
    private val hist = ArrayDeque<Pair<Long, Float>>()
    private var palmSince = 0L

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) startCamera() }
    private val tick = object : Runnable { override fun run() { refresh(); ui.postDelayed(this, 200) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        eyes = EyesView(this); setContentView(eyes)
        try {
            landmarker = HandLandmarker.createFromOptions(this, HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setNumHands(2).setRunningMode(RunningMode.IMAGE).build())
        } catch (e: Exception) { /* sin modelo: no hay gestos de manos, el resto funciona */ }
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME)
        pollBattery(); ui.post(tick)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun pollBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        hot = temp >= 38f
        sad = !plugged && lvl * 100 / sc < 15
        ui.postDelayed({ pollBattery() }, 5000)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        if (abs(g - 9.8f) > 13f) {
            val n = SystemClock.uptimeMillis()
            shakes = if (n - lastShake < 600) shakes + 1 else 1
            lastShake = n
            if (shakes >= 3) angryUntil = n + 3500
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun refresh() {
        val n = SystemClock.uptimeMillis()
        eyes.mood = when {
            n < angryUntil -> Mood.ANGRY
            n < loveUntil -> Mood.LOVE
            n < happyUntil -> Mood.HAPPY
            n < winkUntil -> Mood.WINK
            n < surprisedUntil -> Mood.SURPRISED
            hot -> Mood.HOT
            sad -> Mood.SAD
            dark -> Mood.SLEEPY
            else -> Mood.IDLE
        }
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
            an.setAnalyzer(exec) { analyze(it) }
            val p = f.get(); p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, an)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun d(a: NormalizedLandmark, b: NormalizedLandmark) = hypot(a.x() - b.x(), a.y() - b.y())

    private fun analyze(img: ImageProxy) {
        try {
            val raw = img.toBitmap()
            val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()); postScale(-1f, 1f) }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            val s = Bitmap.createScaledBitmap(bmp, 8, 8, true)
            var sum = 0L
            for (i in 0 until 64) { val c = s.getPixel(i % 8, i / 8); sum += (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
            dark = sum / 64 < 30
            val hands = landmarker?.detect(BitmapImageBuilder(bmp).build())?.landmarks() ?: emptyList()
            val now = SystemClock.uptimeMillis()
            if (hands.isEmpty()) { eyes.lookX = null; hist.clear(); palmSince = 0; return }
            val a = hands[0]
            eyes.lookX = (a[0].x() - .5f) * 2; eyes.lookY = a[0].y() - .5f
            val size = d(a[0], a[9])
            fun ext(tip: Int, pip: Int) = d(a[0], a[tip]) > d(a[0], a[pip]) * 1.1f
            val idx = ext(8, 6); val mid = ext(12, 10); val ring = ext(16, 14); val pnk = ext(20, 18)
            val thumbOut = d(a[4], a[17]) > d(a[3], a[17]) * 1.05f
            val open = idx && mid && ring && pnk
            val curled = !idx && !mid && !ring && !pnk
            hist.addLast(now to a[0].x())
            while (hist.first().first < now - 1000) hist.removeFirst()
            val xs = hist.map { it.second }; val range = xs.max() - xs.min()
            val still = open && range < .06f
            when {
                hands.size == 2 && d(a[4], hands[1][4]) < size * .8f && d(a[8], hands[1][8]) < size * .8f ->
                    loveUntil = now + 2500                                   // corazón con 2 manos
                curled && thumbOut && a[4].y() < a[3].y() && a[3].y() < a[2].y() ->
                    happyUntil = now + 2500                                  // pulgar arriba
                idx && mid && !ring && !pnk -> winkUntil = now + 2000        // paz = guiño
                d(a[4], a[8]) < size * .15f && !open -> loveUntil = now + 2500   // corazón con dedos
                curled -> angryUntil = now + 2000                            // puño = enfado
                open && range > .18f -> happyUntil = now + 2500              // saludar con la mano
                still -> { if (palmSince == 0L) palmSince = now
                    if (now - palmSince > 1200) surprisedUntil = now + 1500 }  // palma quieta = sorpresa
            }
            if (!still) palmSince = 0
        } catch (e: Exception) {
        } finally { img.close() }
    }
}
