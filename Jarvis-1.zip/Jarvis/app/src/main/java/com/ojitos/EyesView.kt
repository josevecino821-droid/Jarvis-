package com.ojitos

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.*
import kotlin.random.Random

enum class Mood { IDLE, ANGRY, HOT, LOVE, SLEEPY, HAPPY, SURPRISED, SAD, WINK, SQUINT, BIG, CROSS }

class EyesView(c: Context) : View(c) {
    @Volatile var mood = Mood.IDLE
    @Volatile var lookX: Float? = null
    @Volatile var lookY = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val black = Paint().apply { color = Color.BLACK }
    private val rect = RectF(); private val path = Path()
    private var lx = 0f; private var ly = 0f; private var tx = 0f; private var ty = 0f
    private var hAmt = 1f; private var blink = 0f; private var nextBlink = 0L; private var wander = 0L
    private var quirk = Mood.IDLE; private var quirkUntil = 0L; private var nextQuirk = 0L
    private val quirks = listOf(Mood.HAPPY, Mood.WINK, Mood.SQUINT, Mood.BIG, Mood.CROSS)

    private fun color(m: Mood) = when (m) {
        Mood.ANGRY -> 0xFFFF3030.toInt(); Mood.HOT -> 0xFFFF9A30.toInt(); Mood.LOVE -> 0xFFFF4F9A.toInt()
        Mood.SLEEPY -> 0xFF7A8CFF.toInt(); Mood.HAPPY -> 0xFFFFE14D.toInt(); Mood.SURPRISED -> Color.WHITE
        Mood.SAD -> 0xFF4D9BFF.toInt(); else -> 0xFF55FFFF.toInt()
    }

    private fun heart(cv: Canvas, x: Float, y: Float, s: Float) {
        path.reset(); path.moveTo(x, y + s * .9f)
        path.cubicTo(x - s * 1.5f, y - s * .1f, x - s * .9f, y - s * 1.1f, x, y - s * .4f)
        path.cubicTo(x + s * .9f, y - s * 1.1f, x + s * 1.5f, y - s * .1f, x, y + s * .9f)
        cv.drawPath(path, p)
    }

    private fun lid(cv: Canvas, x: Float, y: Float, R: Float, inn: Int) {
        path.reset()
        path.moveTo(x - inn * R * 1.2f, y - R * 1.7f); path.lineTo(x + inn * R * 1.2f, y - R * 1.7f)
        path.lineTo(x + inn * R * 1.2f, y - R * .1f); path.lineTo(x - inn * R * 1.2f, y - R * 1.0f)
        path.close(); cv.drawPath(path, black)
    }

    override fun onDraw(cv: Canvas) {
        val now = SystemClock.uptimeMillis(); val t = now / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        // gestos aleatorios cuando no pasa nada
        if (now > nextQuirk) {
            quirk = quirks.random(); quirkUntil = now + 1500 + Random.nextLong(1500)
            nextQuirk = now + 5000 + Random.nextLong(7000)
        }
        val m = if (mood == Mood.IDLE && now < quirkUntil) quirk else mood
        cv.drawColor(Color.BLACK)
        val lk = lookX
        if (lk != null) { tx = lk; ty = lookY }
        else if (now > wander) { tx = Random.nextFloat() * 2 - 1; ty = Random.nextFloat() - .5f; wander = now + 1200 + Random.nextLong(2500) }
        lx += (tx - lx) * .12f; ly += (ty - ly) * .12f
        if (now > nextBlink) { blink = 1f; nextBlink = now + 1800 + Random.nextLong(3500) }
        if (blink > 0) blink = max(0f, blink - .09f)
        val bl = 1f - sin(blink * PI.toFloat()) * .95f
        val target = when (m) { Mood.ANGRY -> .8f; Mood.HOT -> .45f; Mood.SLEEPY -> .06f; Mood.SQUINT -> .35f; Mood.SAD -> .75f; else -> 1f }
        hAmt += (target - hAmt) * .15f
        val R = min(w, h) * .2f; val cy = h * .46f
        p.color = color(m)
        for (side in intArrayOf(-1, 1)) {
            var x = w / 2 + side * w * .22f + lx * R * .5f; val y = cy + ly * R * .4f
            if (m == Mood.HOT) x += sin(t * 14) * R * .04f
            if (m == Mood.ANGRY) x += sin(t * 40) * R * .05f
            if (m == Mood.CROSS) x = w / 2 + side * w * .22f - side * R * .6f
            if (m == Mood.LOVE) { heart(cv, x, y, R * .85f * (1 + sin(t * 8) * .1f)); continue }
            if (m == Mood.HAPPY || (m == Mood.WINK && side == 1)) {      // ojo cerrado ^
                p.style = Paint.Style.STROKE; p.strokeWidth = R * .28f; p.strokeCap = Paint.Cap.ROUND
                rect.set(x - R * .7f, y - R * .5f, x + R * .7f, y + R * .9f)
                cv.drawArc(rect, 200f, 140f, false, p); p.style = Paint.Style.FILL; continue
            }
            val big = m == Mood.BIG || m == Mood.SURPRISED
            val eh = max(R * (if (m == Mood.SURPRISED) 1.5f else 1.25f) * hAmt *
                (if (m == Mood.SLEEPY || big) 1f else bl) * (if (m == Mood.BIG) 1.2f else 1f), 3f)
            val ew = R * .85f * (if (m == Mood.BIG) 1.2f else if (m == Mood.SURPRISED) .8f else 1f)
            rect.set(x - ew, y - eh, x + ew, y + eh)
            cv.drawRoundRect(rect, R * .5f, R * .5f, p)
            when (m) {
                Mood.ANGRY -> lid(cv, x, y, R, -side)
                Mood.SURPRISED -> cv.drawCircle(x + lx * R * .2f, y, R * .28f, black)
                Mood.SAD -> {
                    lid(cv, x, y, R, side)
                    val f = (t * .6f + (if (side > 0) .3f else 0f)) % 1f
                    p.color = 0xFF99DDFF.toInt(); p.alpha = ((1 - f) * 255).toInt()
                    cv.drawCircle(x + side * R * .6f, y + R * .9f + f * R * 1.3f, R * .1f, p)
                    p.alpha = 255; p.color = color(m)
                }
                Mood.HOT -> {
                    p.color = 0xFF66FFFF.toInt()
                    for (i in 0..2) {
                        val f = (t * .8f + i / 3f + (if (side > 0) .17f else 0f)) % 1f
                        p.alpha = ((1 - f) * 255).toInt()
                        val cx = x + (i - 1) * R * .5f; val cyy = y - R * .7f + f * R * 2.2f
                        rect.set(cx - R * .07f, cyy - R * .12f, cx + R * .07f, cyy + R * .12f); cv.drawOval(rect, p)
                    }
                    p.alpha = 255; p.color = color(m)
                }
                Mood.SLEEPY -> { p.textSize = R * .4f; cv.drawText("z", x + side * R * .3f, y - R * .6f - (t * 30) % 40, p) }
                else -> {}
            }
        }
        postInvalidateOnAnimation()
    }
}
