JARVIS - proyecto Android nativo
1. Pon el modelo en app/src/main/assets/hand_landmarker.task
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
2. Abre la carpeta en Android Studio, espera al Gradle sync y pulsa Run.
Reacciones: saludar=feliz | pulgar arriba=feliz | paz=guino | puno=enfado | palma quieta=sorpresa |
corazon (2 manos o dedos)=corazones | agitar=enfado | 38C=calor | bateria<15%=triste | oscuro=sueno
Ademas, solo, pone caras aleatorias (guino, feliz, bizco, entrecerrar, ojos grandes).
